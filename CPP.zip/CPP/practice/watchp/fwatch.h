#ifndef Fwatch_H
#define Fwatch_H

#include<iostream>
#include "watch.h"

class Fwatch:public Watch
{	
	char* os;
public:
	Fwatch(char *mn, int x,char* z);
	~Fwatch();
	friend ostream& operator<<(ostream& out, Fwatch& x);
	void setMode(int); 
};
#endif
