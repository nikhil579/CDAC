#include<iostream>
#include<ostream>
#include<cstring>
#include"watch.h"
using namespace std;

Watch::Watch(char *nm,int x)
{
	name = new char [strlen(nm)+1];
	strcpy (name,nm);
	name [strlen(nm)+1]='\0';
	cost=x;
}

Watch::~Watch()
{
	delete [] name;
	cout<<"destuctor";
}

ostream& operator<<(ostream& out, Watch& x)
{
	out << x.name ;
	out << x.cost ;

}
