#ifndef _Twatch__H
#define _Twatch__H_

#include<iostream>
#include "watch.h"

class Twatch:public Watch
{
public:
	Twatch(char *mn, int x);
	~Twatch();
	bool operator>(Twatch &);
	void setMode(int); 
};
#endif
