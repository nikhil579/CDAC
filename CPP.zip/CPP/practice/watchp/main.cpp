#include"watch.h"
#include"tawtch.h"
#include"fwatch.h"
#include<iostream>
#include<ostream>
using namespace std;

int main()
{
		//This line should give compile time error like "Cant create object of abstract class"
	//Watch *ed = new Watch();

		//A Titan analog Watch of Rs 8000
	Watch *titanWatch = new Twatch("Titan",8000);
	titanWatch->setMode(0);
	titanWatch->playAlaram();
	cout<<endl;
	
	Watch *fastTrackWatch = new Fwatch("FastTrack",9000,"Android");
	fastTrackWatch->setMode(1);
	fastTrackWatch->playAlaram();

	//delete titanWatch;
	//delete fastTrackWatch;	


	//
	Twatch s1("Titan-Sangam",8500);
	Twatch s2("Titan-Pancham",8100);
	
	if(s1>s2)    // Compare on the basis of price of watch...
	cout<<endl;	
	cout<<"sangam is costlier than pancham"<<endl;
/*
	FWatch s3("FastTrack-World",12000,"Android-11");
	cout<<s3;
*/
}
