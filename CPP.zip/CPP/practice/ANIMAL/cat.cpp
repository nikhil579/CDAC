#include"cat.h"
using namespace std;


Cat::Cat()
{

}
Cat::Cat(char *x,int y,int z=0):Animal(x,y)
{
	h=z;
	cout<<"Cat name "<<name<<" ";
	cout<<"Cat age "<<i<<endl;
}
void Cat::speak()
{
	cout<<"Cat speaks"<<endl;
}

Cat::~Cat()
{

}
