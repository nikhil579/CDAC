#ifndef animal_h
#define animal_h
#include<iostream>
#include<ostream>
#include<cstring>
using namespace std;
class Animal
{
protected:
	int i;
	char* name;
public:
	Animal();
	~Animal();
	Animal(int);
	Animal(char *,int);
	Animal(Animal&);
virtual void speak()=0;
friend ostream& operator<<(ostream&,Animal&);
bool operator>(Animal&x);

};
#endif
