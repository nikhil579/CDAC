
#include"dog.h"
using namespace std;


Dog::Dog()
{

}

Dog::Dog(int p):Animal(p)
{
	cout<<"Dog parameter"<<endl;	
	cout<<"value of p is="<<p<<endl;
}
Dog::Dog(char *ptr,int x)
{
	cout<<"Dog name "<<ptr<<"  ";
	cout<<"Dog age "<<i<<endl;
}
void Dog::speak()
{
	cout<<"Dog speak "<<endl;
}

Dog::~Dog()
{
}
