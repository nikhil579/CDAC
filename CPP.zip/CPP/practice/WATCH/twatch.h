#ifndef Twatch_h
#define Twatch_h
#include<iostream>
#include"watch.h"
using namespace std;
class Twatch:public Watch
{

public:
	~Twatch();
	Twatch(char *,int);
	void setmode(int);
	bool operator>(Twatch&);
};
#endif
