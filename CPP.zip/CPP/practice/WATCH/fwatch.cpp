#include<iostream>
#include<cstring>
#include"watch.h"
#include"fwatch.h"

Fwatch::~Fwatch()
{
	delete [] os;
}
Fwatch::Fwatch(char *x,int y,char* z):Watch(x,y)
{
	os=new char[strlen(z)+1];
	strcpy(os,z);
	os[strlen(z)+1]='\0';
}
void Fwatch::setmode(int x){
	mode=x;
}
ostream& operator<<(ostream& out,Fwatch &x){
	out<<"Name"<<x.name<<"";
	out<<"Price"<<x.cost<<"";
	out<<"OS"<<x.os<<"";
	return out;

}
