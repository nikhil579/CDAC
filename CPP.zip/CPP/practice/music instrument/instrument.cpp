#include"instrument.h"
#include<iostream>
#include<ostream>
#include<cstring>

using namespace std;
Instrument::Instrument()
	{
		name=NULL;
		cost=0;
	}

Instrument::Instrument(char*ptr,int x)
{
	name=new char[strlen(ptr)+1];
	strcpy(name,ptr);
	name[strlen(ptr)+1]='\0';
	cost=x;
}

ostream& operator<<(ostream& out,Instrument& x)
{
	out<<"Name is "<<x.name;
	out<<"Cost is "<<x.cost<<endl;
	return out;
}

Instrument::~Instrument()
{
delete [] name;
}
