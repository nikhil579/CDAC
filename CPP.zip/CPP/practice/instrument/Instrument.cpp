#include "Instrument.h"
#include<iostream>
#include<ostream>
#include<cstring>

using namespace std;

Instrument::Instrument()
{
	name=NULL;
	price=0;
}
Instrument::Instrument(char* n, int p)
{
	price=p;
	name=new char[strlen(n)+1];
	strcpy(name,n);
	name[strlen(n)+1]='\0';
}
Instrument::~Instrument()
{
	delete []  name;
}
ostream& operator<<(ostream& out,Instrument& I)
{
	out<<"name is"<<I.name<<endl;
	out<<"price is"<<I.price<<endl;
	return out;
}
