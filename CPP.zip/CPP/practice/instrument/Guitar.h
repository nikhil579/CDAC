#ifndef GUITAR_H
#define GUITAR_H
#include<iostream>
#include<ostream>
#include "Instrument.h"
using namespace std;
class Guitar:public Instrument
{
public:
Guitar();
Guitar(char* , int);
~Guitar();
int playingCost(int);
};
#endif
