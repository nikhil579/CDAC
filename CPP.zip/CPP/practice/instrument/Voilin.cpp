#include "Voilin.h"
#include<iostream>
#include<ostream>
#include<cstring>

using namespace std;

Voilin::Voilin():Instrument()
{
	
}
Voilin::Voilin(char* n, int p):Instrument(n,p)
{
	
}
Voilin::~Voilin()
{
}
int Voilin::playingCost(int a)
{
	cout<<"price for"<<a<<"months is"<<a*price<<endl;
}

