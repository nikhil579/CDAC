#ifndef INSTRUMENT_H
#define INSTRUMENT_H
#include<iostream>
#include<ostream>
using namespace std;
class Instrument
{
	protected:
	char* name;
	int price;

	public:
	Instrument();
	Instrument(char* , int);
	~Instrument();
	virtual int playingCost(int)=0;
	friend ostream& operator<<(ostream&,Instrument&);
};
#endif
