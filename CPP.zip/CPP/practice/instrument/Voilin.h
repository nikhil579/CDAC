#ifndef VOILIN_H
#define VOILIN_H
#include<iostream>
#include<ostream>
#include "Instrument.h"
using namespace std;
class Voilin:public Instrument
{
char* name;
int price;
public:
	Voilin();
	Voilin(char* , int);
	~Voilin();
	int playingCost(int);
};
#endif
