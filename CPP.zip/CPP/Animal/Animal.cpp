#include"Animal.h"
#include"Cat.h"
using namespace std;
Animal::Animal()
{
	cout<<"Animal::Animal()"<<endl;		
}
Animal::Animal(int a)
{
	i=a;
	cout<<"Animal::Animal()"<<endl;		
}
Animal::~Animal()
{
	cout<<"Animal::~Animal()"<<endl;
	delete [] this->name;
}
Animal::Animal(char *x,int y)
{
	i=y;
	name=new char[strlen(x)+1];
	strcpy(name,x);
	
	
}

ostream& operator<<(ostream& out, Animal* z)
{
	out<<"Name:"<<z->name<<endl<<"Age:"<<z->i<<endl;
	Cat*c=dynamic_cast<Cat*>(z);
	if(c!=NULL)
	{
		cout<<"height"<<c->h<<endl;
	}
	return out;
}
bool Animal::operator>(Animal &x)
{
	cout<<"this is greater than"<<endl;
	int month=this->i*12;
	if(month>x.i)
		return true;
	else
		return false;
}
Animal::Animal(Animal &x)
{	
	cout<<"In copy Constructor"<<endl;
	this->i=x.i;
        this->name=new char[strlen(x.name)+1];
 	strcpy(this->name,x.name);
	this->name[strlen(x.name)+1]='\0';
	cout<<"this->i"<<this->i<<endl;
	cout<<"this->name"<<this->name<<endl;
}



