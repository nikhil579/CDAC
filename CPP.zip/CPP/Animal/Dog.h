#ifndef _DOG__H_
#define _DOG__H_
#include"Animal.h"
#include<iostream>
#include<ostream>
#include<cstring>
using namespace std;
class Dog:public Animal
{
	
public:
	Dog();
	Dog(int p);
	Dog(char *x,int y);
	~Dog();
	void speak();
	

};
#endif
