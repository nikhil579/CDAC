#include"Cat.h"
using namespace std;
Cat::Cat()
{
	cout<<"Cat::Cat()"<<endl;		
}
Cat::Cat(char *x,int y,int z=0):Animal(x,y)
{
	h=z;
	cout<<"Age of cat="<<i;
	cout<<"Name of cat="<<name<<endl;
	
}
Cat::~Cat()
{
	cout<<"Cat::~Cat()"<<endl;
}
void Cat::speak()
{
	cout<<"Mewoooooow"<<endl;
}

