#ifndef _ANIMAL__H_
#define _ANIMAL__H_
#include<iostream>
#include<ostream>
#include<cstring>
using namespace std;
class Animal
{
protected:
	int i;
	char *name;
public:
	Animal();
	Animal(int);
	~Animal();
	Animal(char *x,int y);
	virtual void speak()=0;
	friend ostream& operator<<(ostream& out,Animal* z);
	 bool operator>(Animal &x);
	Animal(Animal &);
	
	

};
#endif
