#include<iostream>

#include"Emp.h"
int main()
{
	Emp e1;
	Emp e2("Ram");
	Emp e3(e2);
	Emp e4=e3;
	cout<<e3;
	
}
