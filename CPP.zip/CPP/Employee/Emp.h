#include<iostream>
#include<cstring>
#include<ostream>
using namespace std;
class Emp
{
	   int id;
	   char *name;
public:
	Emp();
	Emp(const char *x);
	~Emp();
	Emp(const Emp &x); 
	void operator=(const Emp &x);
	friend ostream& operator<<(ostream& harsh,Emp &x);
		
};


