#include<iostream>
#include<cstring>

	int main()
		{
		Overload s("Nikhil"); 
		Overload s2("Sonawane);
		s.display();
		s2.display();
		cout<<"+" <<endl;               
		s+s2;


		cout<<"==" <<endl; 
		bool i=(s==s2) ;
		if(i){
				 cout<<"Same";

		}
		else{
			cout<<"NOT Same";
			
}

return 0;
}
