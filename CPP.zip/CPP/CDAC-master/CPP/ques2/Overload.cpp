#include"Overload.h"
using namespace std;
#include<ostream>
	Overload::Overload(){
	fname="null";
	lname="null";
}
	Overload::~Overload(){
	//delete[] fname;
	//delete[] lname;
}

Overload::Overload(char* fname){
			this->fname=fname;
}
void Overload::operator+(char* fnm,char* lnm){
	fname=new char[(strlen(fnm)+1)];
	lname=new char[(strlen(lnm)+1)];
	strcpy(fname,fnm);
	strcpy(lname,lnm);
	fname[strlen(fnm)+1]='\0';
	lname[strlen(lnm)+1]='\0';
	tname=new char[(fnm)+(lnm)];
	
	}


void Overload::display(){
			cout<<"NAME: "<<fname<<endl;
			cout<<"Surname: "<<lname<<endl;
			

}
/*ostream operator<<(ostream& out,Overload emp){
			out<<"ID: "<<id<<endl;
			out<<"NAME: "<<name<<endl;
			out<<"CITY: "<<city<<endl;
			out<<"SALARY: "<<sal<<endl;
}*/
Overload::~Overload(){
	//cout<<"Destructor"<<endl;
	delete[] name;
	delete[] city;
}
