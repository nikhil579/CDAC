#include<iostream>
#include<cstring>

using namespace std;

class Overload
		{
		private:
		char *name;
		public:
			Overload(){
			name=new char(20);
			strcpy(name,"Nikhil");
				}

			Overload( const char *tname){
			name=new char(sizeof tname);
			strcpy(name,tname);
				}

			void operator +( const Overload &tname){
				 	  Overload s;
				  s.name= new char(sizeof(this->name)+sizeof(tname.name));
				  strcpy(s.name,this->name);
				  strcat(s.name,tname.name);
				  cout<<s.name <<endl;
			}

		  	 bool operator == ( Overload &tname){			
				if(strlen(this->name)==strlen(tname.name)) {
				
				   return 1;
			 	}
				else
				{
				
				return 0;
				}
			}

			 
				void display()
			{
				cout<<name <<endl;
			}
		};

