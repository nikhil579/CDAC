

class Point
{
	int x;
	int y;
	
public:
	Point();
	Point(int, int);
	void display();
	~Point();
};

