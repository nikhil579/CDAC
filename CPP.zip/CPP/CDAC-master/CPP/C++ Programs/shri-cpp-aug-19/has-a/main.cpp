#include <iostream>
#include <iostream>
#include "A.h"
#include "B.h"
using namespace std;

int main(int argc, char** argv) 
{
	A a;
	A b(10);
	A c(10,20);
	
	a.show();
	b.show();
	c.show();
}


