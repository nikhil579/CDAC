
#ifndef __A__H__
#define __A__H__
#include "B.h"

class A
{
	int i;
	B b;
public:
	A();
	A(int x);	
	A(int x, int y);	
	~A();

	void show();
};

#endif

