#include <iostream>
#include "A.h"
using namespace std;

A::A()
{
	i=0;	
	cout<<"A::A()"<<endl;
}

A::A(int x)
{
	i=x;
	cout<<"A::A(int)"<<endl;
}

A::A(int x, int y) : b(y)
{
	i=x;	
	cout<<"A::A(int,int)"<<endl;
}

A::~A()
{
	cout<<"A::~A()"<<endl;
}

void A::show()
{
	cout<<"A::show()"<<endl;
	cout<<"I="<<i<<endl;
	b.show();
}

