
#ifndef __B__H__
#define __B__H__

class B 
{
	int j;
public:
	B();
	B(int x);
	~B();

	void show();
};

#endif

