#include <iostream>
#include <iostream>
#include "A.h"
#include "B.h"
#include "C.h"
using namespace std;

int main(int argc, char** argv) 
{
	
	C c;
	c.fun();
	c.fun2();
	
	
		
}


