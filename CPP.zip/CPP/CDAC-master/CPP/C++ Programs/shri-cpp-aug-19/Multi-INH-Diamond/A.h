
#ifndef __A__H__
#define __A__H__

class A
{
	
public:
	A();
	~A();
	void fun();
};

#endif

