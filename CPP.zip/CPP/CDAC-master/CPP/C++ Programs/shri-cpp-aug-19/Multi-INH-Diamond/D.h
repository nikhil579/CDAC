
#ifndef __D__H__
#define __D__H__

#include "B.h"
#include "C.h"

class D : public B, public C
{
public:
	D();
	~D();
};

#endif

