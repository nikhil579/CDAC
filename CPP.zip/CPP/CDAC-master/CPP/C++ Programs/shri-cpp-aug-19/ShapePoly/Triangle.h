#ifndef __TRI_H__
#define __TRI_H__

#include <iostream>
#include "Shape.h"
using namespace std;

class Triangle : public Shape
{
	
	public:
		
		void draw()
		{
			cout<<"Triangle::Draw()"<<endl;
		}
};

#endif

