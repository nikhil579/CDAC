#include <cstdio>
#include "ABC.h"

int main()
{

	ABC a;
	a.display();	
	
	ABC b(20);
	b.display();

}


