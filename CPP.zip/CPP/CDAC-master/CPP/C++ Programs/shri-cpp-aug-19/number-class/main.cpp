
#include <iostream>
using namespace std;

#include "Number.h"

int main()
{
	Number num1, num2;
	cin>>num1;
	cin>>num2;


	Number num3 = MathOperations.addition(num1, num2);

	cout<<num3<<endl;
}



