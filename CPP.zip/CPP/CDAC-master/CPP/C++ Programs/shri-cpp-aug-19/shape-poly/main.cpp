

#include <iostream>
using namespace std;
#include "Shape.h"
#include "Circle.h"
#include "Triangle.h"

int main()
{
	Shape *ptr = new Circle();
	ptr->draw();

	delete ptr;
}


