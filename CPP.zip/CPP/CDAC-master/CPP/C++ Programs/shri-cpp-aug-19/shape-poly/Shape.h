
#ifndef _SHAPE__H_
#define _SHAPE__H_

class Shape
{
	
public:
	Shape();
	virtual ~Shape();
	virtual void draw()=0;
};

#endif

