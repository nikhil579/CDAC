

#include <iostream>
using namespace std;
#include "Triangle.h"

Triangle::Triangle()
{
	cout<<"Triangle::Triangle()"<<endl;
}

Triangle::~Triangle()
{
	cout<<"Triangle::~Triangle()"<<endl;
}

void Triangle::draw()
{
	cout<<"Triangle::Draw()"<<endl;
}

