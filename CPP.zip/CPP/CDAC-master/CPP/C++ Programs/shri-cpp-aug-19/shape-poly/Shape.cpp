
#include <iostream>
using namespace std;
#include "Shape.h"

Shape::Shape()
{
	cout<<"Shape::Shape()"<<endl;
}

Shape::~Shape()
{
	cout<<"Shape::~Shape()"<<endl;
}

