
#include <ostream>
using namespace std;

#define STACK_SIZE 10

class Stack
{
	int arr[STACK_SIZE];
	int top;

public:
	Stack();
	~Stack();
	Stack(Stack &);
	void operator=(Stack &);
	void push(int x);
	int pop();
	friend ostream& operator<<(ostream &out, Stack &x);
};


