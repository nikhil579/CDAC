

#ifndef _A__H_
#define _A__H_

class A
{
	int i;
public:
	A();
	~A();
	void fun();
	void fun(int x);
	void display();
};

#endif

