#include <iostream>
#include <stdlib.h>

#include "ABC.h"


int main(int argc, char** argv) 
{
	ABC a;
	a.showMe();	
		
	
	const ABC b;
	b.showMe();
	
	a=b;
	
	ABC::fun();
	
	
	
	
	
	
}


