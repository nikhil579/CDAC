

class ABC
{
	int i;
	static int s;
	const int c;
	int &r;
	int *ptr;
	
	public:
		
		~ABC();
		ABC();
		void operator=( const ABC &x) ;
		void showMe() const;
		void ChangeS(int x);
		void ChangeI(int x);
		
		static void fun();

};




