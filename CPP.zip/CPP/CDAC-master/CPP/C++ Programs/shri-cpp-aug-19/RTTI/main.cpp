#include <iostream>
#include "Shape.h"
#include "Circle.h"
#include "Triangle.h"
#include "MyClass.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) 
{
	
	Circle c1;
	Triangle t1;
	
	MyClass myclass;
	myclass.fun(&t1);
	
	
	
	
}


