

class Circle
{

	int rad;
	int x;
	int y;
	
	//-------------------
public:	
	void display();
	float getArea();
	Circle();
	Circle(int );
	Circle(int , int , int );
	~Circle();
};

