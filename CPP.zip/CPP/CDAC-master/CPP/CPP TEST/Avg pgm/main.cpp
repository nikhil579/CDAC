#include<iostream>
using namespace std;
#include<fstream>
void takein();
void avg();
int temp[10],i=0,sum=0,avg1=0;	
int main()
{
	
	takein();
	avg();
	

return 0;
}



void takein()
{
// For Taking An Input from an user for entering an file:


ofstream fout("a.txt",ios::out);
	cout<<"Enter 5 Numbers :"<<endl;
	 for(i;i<5;i++)
		{
			cin>>temp[i];
			fout<<temp[i];
		}
	fout.close();
}




void avg()
{

//For calculating an Avg of Element From same file:

	ifstream fin("a.txt",ios::in);
	
	cout<<"File Elements Are as Follows"<<endl;
		
	while(fin>>temp[i])
	{	
		cout<<temp[i]<<endl;
		i++;	
	}
	
	for(int i=0;i<5;i++)
	{
		sum=sum+temp[i];
	}
		cout<<"Average="<<sum/5<<endl;

	fin.close();
}

