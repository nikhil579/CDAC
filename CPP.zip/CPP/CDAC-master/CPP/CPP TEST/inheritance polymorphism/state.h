#ifndef _State__H
#define _State__H
#include<ostream>
using namespace std;
class State
{
  protected :
   		char *language;
   		int area;
   	public:
   		State();
   		~State();
   		State(const char * ,int);
   		virtual void MyTourismSpots();
	        friend ostream & operator<<(ostream &out,State &);
		bool operator>(State &);
};
#endif
