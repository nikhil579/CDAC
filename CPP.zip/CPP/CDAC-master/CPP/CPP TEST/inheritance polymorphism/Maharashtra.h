#ifndef _Maharashtra__H
#define _Maharashtra__H

#include"state.h"
class Maharashtra:public State
{
 
 public:
       Maharashtra();
       ~Maharashtra();
	Maharashtra(const char * ,int);	
	void MyTourismSpots();

};
#endif
