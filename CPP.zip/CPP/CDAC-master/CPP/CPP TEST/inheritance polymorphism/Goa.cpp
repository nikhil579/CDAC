#include<iostream>
using namespace std;
#include"state.h"
#include<cstring> 
#include"Goa.h"
     Goa::Goa()
     {
     cout<<"constructor";
     
     }
        Goa::~Goa()
        {
        cout<<"destructor";
        
        }
	 Goa::Goa(const char *l ,int a):State(l,a)
	 {
	 
	 
	 
	 }	
	 
	 void  Goa::MyTourismSpots()
   		{
   		cout<<" In  Goa MyTourismSpots   "<<endl<<language<<endl<<area<<endl;
   		
   		}
   		
