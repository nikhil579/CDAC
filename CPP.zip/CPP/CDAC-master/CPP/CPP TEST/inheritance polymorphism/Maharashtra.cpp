#include<iostream>
using namespace std;
#include"state.h"
#include<cstring> 
#include"Maharashtra.h"
     Maharashtra::Maharashtra()
     {
     cout<<"constructor";
     
     }
        Maharashtra::~Maharashtra()
        {
        cout<<"destructor";
        
        }
	 Maharashtra::Maharashtra(const char *l ,int a):State(l,a)
	 {
	 
	 
	 
	 }	
	 
	 void  Maharashtra::MyTourismSpots()
   		{
   		cout<<" In  Maharashtra MyTourismSpots   "<<language<<endl<<area<<endl;
   		
   		}
   		
