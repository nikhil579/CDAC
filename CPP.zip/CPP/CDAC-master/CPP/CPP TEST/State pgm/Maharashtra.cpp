
#include"Maharashtra.h"
Maharashtra::Maharashtra()
{
	

}
Maharashtra::Maharashtra(const char *x,int n):State(x,n)
{
	
}
Maharashtra::~Maharashtra()
{
	
}

