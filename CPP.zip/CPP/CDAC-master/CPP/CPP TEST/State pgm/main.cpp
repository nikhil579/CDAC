#include"Goa.h"
#include"Maharashtra.h"
#include"State.h"
int main()
{
	State *ptr=new State();
	State *ms=new Maharashtra("Marathi",12800);
	State *goa=new Goa("Kokani",800);

	cout<<*ms<<endl;

	goa->MyTourisumSpots();

if((*ms)>(*goa))
	cout<<"Ms is Greater"<<endl;
	


delete ms;
delete goa;


}
