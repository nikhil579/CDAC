#include"State.h"
#include"Goa.h"
Goa::Goa()
{

	

}
Goa::Goa(const char *x,int n):State(x,n)
{
	

}
Goa::~Goa()
{

}
void Goa::MyTourisumSpots()
{
	cout<<"Visiting Spots Are:"<<endl;
	cout<<"Beaches"<<endl<<"Parks"<<endl<<"Sunset Points"<<endl;
}
