
#include<iostream>
using namespace std;
#include<ostream>
#ifndef _MAHARASTRA__H_
#define _MAHARASHTRA__H_
#include"State.h"
class Maharashtra:public State
{

public:	
	Maharashtra();
	Maharashtra(const char *,int);
	~Maharashtra();
	
};
#endif
