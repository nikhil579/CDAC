#include"FWatch.h"
#include<iostream>
#include"Watch.h"


FWatch::FWatch(char *nn, int z,char *xm):Watch(nn,z)
{
	os=new char[strlen(xm)+1];
	strcpy(os,xm);
	name[strlen(xm)]='\0';
	



}

FWatch::~FWatch()
{
	
	delete [] os;
	cout<<"in Twatch destructor"<<endl;
}
void FWatch::setMode(int n)	
{
		Mode=n;
}
ostream& operator<<(ostream& out,FWatch &x)
{
	out<<"nameofwatch"<<x.name<<endl;
	out<<"costofwatch"<<x.cost<<endl;
	out<<"osofwatch"<<x.os<<endl;
	return out;
}

