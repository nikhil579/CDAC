#include"Watch.h"
#include<iostream>


Watch::Watch(char *nm, int x)
{

	name=new char[strlen(nm)+1];
	strcpy(name,nm);
	name[strlen(nm)+1];
	cost=x;
}
Watch::~Watch()
{	
	delete [] name;
	cout<<"in watch destructor"<<endl;
}
