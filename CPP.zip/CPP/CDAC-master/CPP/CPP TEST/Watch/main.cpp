#include"Watch.h"
#include"TWatch.h"
#include"FWatch.h"
#include<ostream>
int main()
{
		//This line should give compile time error like "Cant create object of abstract class"
	//Watch *ed = new Watch();

		//A Titan analog Watch of Rs 8000
	Watch *titanWatch = new TWatch("Titan",8000);
	titanWatch->setMode(0);

	Watch *fastTrackWatch = new FWatch("FastTrack",9000,"Android");
	fastTrackWatch->setMode(1);
	
	titanWatch->playAlaram();
	fastTrackWatch->playAlaram();

	delete titanWatch;
	delete fastTrackWatch;	


	//Another two banks have same rate of interest
	TWatch s1("Titan-Sangam",8500);
	TWatch s2("Titan-Pancham",8100);
	
	if(s1>s2)    // Compare on the basis of price of watch...
		
	cout<<"sangam is > pancham"<<endl;

	FWatch s3("FastTrack-World",12000,"Android-11");
	cout<<s3;

}
