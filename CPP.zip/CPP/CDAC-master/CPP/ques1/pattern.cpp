#include<iostream>
#include<cstdio>
using namespace std;

int main(){

cout<<"Enter a number: "<<endl; 
int num;
char* let="A";
cin>>num;
	for(int i=0;i<num;i++){
		for(int j=0;j<i;j++){
			cout<<let;
						
	}cout<<"\n";
	}

}
