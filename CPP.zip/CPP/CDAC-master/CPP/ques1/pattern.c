#include<stdio.h>

int main(){
	int num=0;
//	int count=0;
	printf("Enter a number:");
	scanf("%d",&num);
	int let=65;
	for(int i=0; i<=num ;i++){
		for(int j=0 ; j<i ;j++){
			printf("%c",let++);
		}	
	printf("\n");
	}
}
