//ANIMAL.h
#include<iostream>
#include<cstring>
using namespace std;
class Animal
{
protected:

public:
	int i;
	char *name;
	Animal();
	Animal(int);
	~Animal();
	Animal(char *x,int y);
	virtual void speak()=0;
	bool operator>(Animal &x);
	Animal(Animal &);
};
//cat.h
class Cat:public Animal
{
public:
int h;
	Cat();
	//Cat(char* x,int y);
	Cat(char* x,int y,int z);
	~Cat();
	void speak();
};
//dog.h
class Dog:public Animal
{
	
public:
	Dog();
	Dog(int p);
	Dog(char *x,int y);
	~Dog();
	void speak();
};

//ANIMAL.cpp
Animal::Animal()
{
	cout<<"Animal::Animal()"<<endl;		
}
Animal::Animal(int a)
{
	i=a;
	cout<<"Animal::Animal()"<<endl;		
}
Animal::~Animal()
{
	cout<<"Animal::~Animal()"<<endl;
	delete [] this->name;
}
Animal::Animal(char *x,int y)
{
	i=y;
	name=new char[strlen(x)+1];
	strcpy(name,x);
	
	
}

/*ostream& operator<<(ostream& out, Animal* z)
{
	out<<"Name:"<<z->name<<endl<<"Age:"<<z->i<<endl;
	Cat*c=dynamic_cast<Cat*>(z);
	if(c!=NULL)
	{
		cout<<"height"<<c->h<<endl;
	}
	return out;
}*/
bool Animal::operator>(Animal &x)
{
	cout<<"this is greater than"<<endl;
	int month=this->i*12;
	if(month>x.i)
		return true;
	else
		return false;
}
Animal::Animal(Animal &x)
{	
	cout<<"In copy Constructor"<<endl;
	this->i=x.i;
        this->name=new char[strlen(x.name)+1];
 	strcpy(this->name,x.name);
	this->name[strlen(x.name)+1]='\0';
	cout<<"this->i"<<this->i<<endl;
	cout<<"this->name"<<this->name<<endl;
}
//cat.cpp
Cat::Cat()
{
	cout<<"Cat::Cat()"<<endl;		
}
Cat::Cat(char *x,int y,int z=0):Animal(x,y)
{
	h=z;
	cout<<"Age of cat="<<i;
	cout<<"Name of cat="<<name<<endl;
	
}
Cat::~Cat()
{
	cout<<"Cat::~Cat()"<<endl;
}
void Cat::speak()
{
	cout<<"Mewoooooow"<<endl;
}

//dog.cpp
Dog::Dog()
{
	cout<<"Dog::Dog()"<<endl;		
}

Dog::Dog(int p):Animal(p)
{
cout<<"in dog parameter"<<endl;	
cout<<"value of p is="<<p<<endl;
}
Dog::Dog(char *x,int y):Animal(x,y)
{

	cout<<"Age of Dog="<<i;
	cout<<"Name of Dog="<<name<<endl;
	
}
Dog::~Dog()
{
	cout<<"Dog::~Dog()"<<endl;
}
void Dog::speak()
{
	cout<<"BHoooo BHoooo"<<endl;
}


//main.cpp
int main()
{
	//Animal *ptr = new Animal();

	Animal *dog = new Dog((char*)"Boss",8*12);
	Animal *cat = new Cat((char*)"Pinky",2,7);

	cout<<dog<<endl;
	cout<<cat<<endl;
	if(*cat>*dog)
	{
cout<<".............";
		cat->speak();
	}
	else
	{
		dog->speak();
	}
	delete dog;
	delete cat;
	
 cout<<"--------------------"<<endl;
     Dog d((char*)"king",12);
     d.speak();
cout<<"--------------------"<<endl;
	Dog c(d);
	c.speak();
	
}
