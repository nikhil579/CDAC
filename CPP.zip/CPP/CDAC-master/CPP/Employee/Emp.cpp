#include<iostream>
#include"Emp.h"
using namespace std;
Emp::Emp()
{	
	cout<<"default constructor"<<endl;
	id=1;
	name=new char[strlen("harshal")+1];
	strcpy(name,"harshal");
	cout<<"Id="<<id<<endl;
	cout<<"Name="<<name<<endl;
}
Emp::Emp(const char *x)
{
	cout<<"parameterize constructor"<<endl;
	id=2;
	name=new char[strlen(x)+1];
	strcpy(name,x);
	name[strlen(x)+1]='\0';
	cout<<"Id="<<id<<endl;
	cout<<"Name="<<name<<endl;
}
Emp::~Emp()
{    

	cout<<"destructor"<<endl;
		
}
Emp::Emp(const Emp &x)
{
	
	cout<<"this is copy constructor"<<endl;
	this->id=x.id;
	this->name=new char[strlen(x.name)+1];
	strcpy(this->name,x.name);
	this->name[strlen(x.name)+1]='\0';
	cout<<"Id="<<this->id<<endl;
	cout<<"Name="<<this->name<<endl;
} 
void Emp::operator=(const Emp &x)
{
    cout<<"this is assingment Operator"<<endl;
	delete [] this->name;
	this->id=x.id;
	this->name=new char[strlen(x.name)+1];
	strcpy(this->name,x.name);
	this->name[strlen(x.name)+1]='\0';
	cout<<"Id="<<this->id<<endl;
	cout<<"Name="<<this->name<<endl;
}
ostream& operator<<(ostream& harsh,Emp &x)
{
	harsh<<"this is Extraction operator"<<endl;
	harsh<<"Employee name="<<x.name;
	return harsh;
}
