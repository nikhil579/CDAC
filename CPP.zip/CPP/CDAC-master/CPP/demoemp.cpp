#include<iostream>
using namespace std;
class employee
{
  char name[10];
  int eid;
  public :
	 void get1()
	  {
		cout<<"\nEnter name  : ";
		cin>>name;
		cout<<"\nEnter employee id : ";
		cin>>eid;
	  }
	  void put1()
	  {
		cout<<"\nNAME : "<<name;
		cout<<"\nEMP ID : "<<eid;
	  }
};

class clerk : public employee
{
  int work_days,present,rate;
  public :
	 void get2()
	  {
		get1();
		cout<<"\nEnter no. of working days : ";
		cin>>work_days;
		cout<<"\nEnter no. of days present : ";
		cin>>present;
	  }
	 int absent2()
	  {
		return work_days-present;
	  }
	 int rate2()
	  {
		return rate=1000;
	  }
	 int present2()
	  {
		return present;
	  }
	 void put2()
	  {
		put1();
		cout<<"\nTOTAL NO. OF WORKING DAYS  : "<<work_days;
		cout<<"\nDAYS PRESENT : "<<present;
		cout<<"\nDAYS ABSENT  : "<<absent2();
	  }
};

class mgr : public employee
{
  int work_days,present,rate;
  public :
	 void get3()
	  {
		get1();
		cout<<"\nEnter no. of working days : ";
		cin>>work_days;
		cout<<"\nEnter no. of days present : ";
		cin>>present;
	  }
	 int absent3()
	  {
		return work_days-present;
	  }
	 int rate3()
	  {
		return rate=2000;
	  }
	 int present3()
	  {
		return present;
	  }
	 void put3()
	  {
		put1();
		cout<<"\nTOTAL NO. OF WORKING DAYS  : "<<work_days;
		cout<<"\nDAYS PRESENT : "<<present;
		cout<<"\nDAYS ABSENT  : "<<absent3();
	  }
};

class payslip : public clerk , public  mgr
{
  int pos,salary;
  public :
	 void get4()
	  {
		get2();
		cout<<"\nPOSITION\n1 CLERK\n2 MANAGER\nUR position : ";
		cin>>pos;
	  }
	 int sal()
	  {
		if(pos==1)
		 salary = present2()*rate2();
		if(pos==2)
		 salary = present3()*rate3();
		return salary;
	  }
	 void put4()
	 {
		   put2();
		   cout<<"\nSALARY : "<<sal();
	  }	
};

int main()
{
  payslip p;

  p.get4();
  cout<<endl;
  p.put4();

}



