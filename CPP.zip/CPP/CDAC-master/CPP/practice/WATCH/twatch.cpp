#include<iostream>
#include"watch.h"
#include"twatch.h"

Twatch::~Twatch()
{
}

Twatch::Twatch(char *x,int y):Watch(x,y)
{
		/*name=new char[strlen(nm)+1];
	strcpy(name,nm);
	name[strlen(nm)+1];
	cost=x;*/

}

void Twatch::setmode(int x)
{
	mode=x;
}
bool Twatch::operator>(Twatch &x)
{
	if(this->cost > x.cost)
		return true;
	else
		return false;
}
