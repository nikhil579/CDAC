#ifndef watch_h
#define watch_h
#include<iostream>

using namespace std;

class Watch
{
protected: 
		char *name;
		int cost;
		int mode;
public:
		~Watch();
 		Watch(char *,int);
 		virtual void setmode(int)=0;
 		void playalarm()
 		{
 		if(mode==0)
			cout<<"titan watch rings"<<endl;
		else
			cout<<"fasttrack watch rings"<<endl;
		}	
};
#endif
