#include<iostream>
#include<ostream>
#include"watch.h"
#include"twatch.h"
#include"fwatch.h"
int main()
{
		//This line should give compile time error like "Cant create object of abstract class"
	//Watch *ed = new Watch();

		//A Titan analog Watch of Rs 8000
	Watch *titanWatch = new Twatch("Titan",8000);
	titanWatch->setmode(0);
	titanWatch->playalarm();

	Watch *fastTrackWatch = new Fwatch("FastTrack",9000,"Android");
	fastTrackWatch->setmode(1);
	fastTrackWatch->playalarm();

	delete titanWatch;
	delete fastTrackWatch;	


	//Another two banks have same rate of interest
	Twatch s1("Titan-Sangam",8500);
	Twatch s2("Titan-Pancham",8100);
	
	if(s1>s2)    // Compare on the basis of price of watch...
		
	cout<<"Sangam is costlier than"<<endl;

	Fwatch s3("FastTrack-World",12000,"Android-11");
	cout<<s3;

}
