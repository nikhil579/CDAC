#ifndef Fwatch_h
#define Fwatch_h
#include<iostream>
#include<ostream>
#include"watch.h"
using namespace std;
class Fwatch:public Watch
{
		char *os;
public:
		Fwatch();
 		~Fwatch();
 		Fwatch(char *,int,char *);
 		void setmode(int);
 		friend ostream& operator<<(ostream& out,Fwatch &x);
};
#endif
