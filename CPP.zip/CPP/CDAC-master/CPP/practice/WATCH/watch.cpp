#include"watch.h"
#include<iostream>
#include<cstring>

Watch::Watch(char *ptr,int x)
{	
	name=new char[strlen(ptr)+1];
	strcpy(name,ptr);
	name[strlen(ptr)+1]='\0';
	cost=x;
}
Watch::~Watch()
{
	delete [] name;
}
