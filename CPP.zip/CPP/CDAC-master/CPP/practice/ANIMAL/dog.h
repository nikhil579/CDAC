#ifndef Dog_h
#define Dog_h
#include<iostream>
#include<ostream>
#include<cstring>
#include"animal.h"
using namespace std;
class Dog:public Animal
{
public:
	Dog();
	~Dog();
	Dog(int);
	Dog(char *,int);
	void speak();
};
#endif
