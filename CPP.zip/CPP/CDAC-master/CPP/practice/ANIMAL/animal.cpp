#include"animal.h"
using namespace std;

Animal::Animal()
{
	i=10;
	name="Rambo";
	cout<<""<<endl;
}
Animal::Animal(int a)
{
	i=a;
}
Animal::~Animal()
{
	delete [] this->name;
}

Animal::Animal(char *ptr,int x)
{
	i=x;
	name=new char[strlen(ptr)+1];
	strcpy(name,ptr);
	name[strlen(ptr)+1]='\0';
}
Animal::Animal(Animal &x)
{
	this->i=x.i;
	this->name=new char[strlen(x.name)+1];
	strcpy(this->name,x.name);
	this->name[strlen(x.name)+1]='\0';
	cout<<this->i<<endl;
	cout<<this->name<<endl;

}
bool Animal::operator>(Animal&x)
{	cout<<"this is greater than"<<endl;
	//int month=this->i*12;
	if(this->i > x.i)
		return true;
	else
		return false;
}
ostream& operator<<(ostream& out,Animal& x)
{
	out<<x.name<<" ";
	out<<x.i<<endl;
}
