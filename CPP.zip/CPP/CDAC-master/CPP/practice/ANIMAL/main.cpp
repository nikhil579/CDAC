#include"animal.h"
#include"dog.h"
#include"cat.h"
#include<iostream>
using namespace std;
int main()
{
	//Animal *ptr = new Animal();
	Animal *dog = new Dog("Kutta",12*8);
	cout<<*dog<<endl;
	
	Animal *cat = new Cat("Billa",20,2);
	cout<<*cat<<endl;

	if(*cat>*dog)
	{
		cat->speak();
	}
	else
	{
		dog->speak();
	}
	
	
	Dog d("Rambo",15);
	 d.speak();
	

}
	
	
