#ifndef Cat_h
#define Cat_h
#include<iostream>
#include<ostream>
#include<cstring>
#include"animal.h"
using namespace std;
class Cat:public Animal
{
	int h;
public:
	Cat();
	Cat(int);
	Cat(char *,int,int);
	void speak();
	friend ostream& operator<<(ostream& out,Animal* z);
	~Cat();
};
#endif
