#ifndef violin_h
#define violin_h
#include<iostream>
#include<ostream>
#include "instrument.h"
using namespace std;
class Violin:public Instrument
{
public:
	Violin();
	~Violin();
	Violin(char*,int);
	int playingcost(int);
};
#endif
