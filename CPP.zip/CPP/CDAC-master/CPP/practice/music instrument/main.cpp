#include<iostream>
#include<ostream>
#include"instrument.h"
#include"violin.h"

int main()
{
	//Instrument *instrumentPtr = new Instrument();
	Instrument *instrumentPtr = new Violin("Violin", 3000);
	instrumentPtr->playingcost(4);
	/*delete instrumentPtr;

	//Guitar instrument will cost 1500 RS per month as rent and its name is "Guitar"
	instrumentPtr = new Guitar("Guitar", 1500);
	//I wanted to use this instrument for 8 months, so wanted to know the overall cost
	instrumentPtr->playingCost(8);
	delete instrumentPtr;
	//Print the details of Instrument in our own fashion.
	Guitar guitar("My Guitar", 1800);
	Voilin violin("My Violin", 2200);
	cout<<"Guitar Details Are:"<<guitar<<endl;
	cout<<"Violin Details Are:"<<violin<<endl;	*/
}
