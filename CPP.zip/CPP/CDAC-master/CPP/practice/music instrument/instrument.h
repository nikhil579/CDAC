#ifndef instrument_h
#define instrument_h
#include<iostream>
#include<ostream>
using namespace std;
class Instrument
{
protected:
	int cost;
	char* name;
public:
	Instrument();
	~Instrument();
	Instrument(char*, int);
	virtual int playingcost(int)=0;
	friend ostream& operator<<(ostream&,Instrument&);
};
#endif
