#include<iostream>
#include<ostream>
#include<cstring>
#include"violin.h"
using namespace std;
Violin::Violin():Instrument()
{
}
Violin::~Violin()
{
}
Violin::Violin(char* ptr,int x):Instrument(ptr,x)
{
	
}
int Violin::playingcost(int x)
{
	cout<<"Price for"<<x<<"months"<<x*cost<<endl;
}
