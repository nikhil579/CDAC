#include "Guitar.h"
#include "Instrument.h"
#include<iostream>
#include<ostream>
#include<cstring>

using namespace std;

Guitar::Guitar():Instrument()
{
	
}
Guitar::Guitar(char* n, int p):Instrument(n,p)
{
	
}
Guitar::~Guitar()
{
}
int Guitar::playingCost(int a)
{
	cout<<"price for"<<a<<"months is"<<a*price<<endl;
}

