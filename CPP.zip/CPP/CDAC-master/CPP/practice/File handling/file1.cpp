//read file wala program

#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	fstream ff;
	ff.open("a.txt");
	int i=0;
	ifstream fin("a.txt",ios::in);
	char tmp[100];
	while(fin>>tmp)
	{
		cout<<tmp<<endl;
	}
	fin.close();

}
