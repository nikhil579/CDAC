//add two numbers from one file to another

#include<iostream>
#include<fstream>

using namespace std;
int main()
