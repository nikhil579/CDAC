#include<cstring>
#include<iostream>
#include"fwatch.h"
#include"watch.h"
using namespace std;


Fwatch::Fwatch(char *mn, int x,char* z):Watch(mn,x)
{
	os= new char[strlen(z)+1];
	strcpy(os,z);
	os[strlen(z)+1]='\0';

}
Fwatch::~Fwatch()
{
	delete [] os;
}
ostream& operator<<(ostream& out, Fwatch& x)
{
	out<<"Name"<<x.name;
	out<<"Price"<<x.cost;
	out<<"OS"<<x.os<<endl;
}
void Fwatch::setMode(int n)
{
	mode=n;
}
