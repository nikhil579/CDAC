#include<cstring>
#include<iostream>
#include"tawtch.h"
#include"watch.h"
using namespace std;

Twatch::Twatch(char *mn, int x):Watch(mn, x)
{
/*	name = new char [strlen(nm)+1];
	strcpy(name,nm);
	name[strlen(nm)+1];
	cost=x;
*/}

Twatch::~Twatch()
{
	delete [] name;
cout<<"hi";
}

bool Twatch::operator>(Twatch &x)
{
	if(this->cost > x.cost)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void Twatch::setMode(int n)
{
	mode=n;
}
