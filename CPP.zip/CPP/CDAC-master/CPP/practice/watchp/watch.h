#ifndef _Watch__H_
#define _Watch__H_
#include<iostream>
using namespace std;

class Watch
{
protected:
	char *name;
	int cost;
	int mode;
public:
	Watch(char *nm,int x);
	~Watch();
	virtual void setMode(int)=0;
	friend ostream& operator<<(ostream& out, Watch& x);
	void playAlaram()
	{
		if(mode==0)
			cout<<"TITAN WATCH RINGS";
		else 
			cout<<"FASTTRACK";
	} 
};
#endif
