#ifndef Worker_h
#define Worker_h
#include<iostream>
#include<cstring>
#include<ostream>
class Worker{
private:
		
public:

};

#endif
