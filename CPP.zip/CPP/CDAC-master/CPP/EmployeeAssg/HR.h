#ifndef HR_h
#define HR_h
#include<iostream>
#include<cstring>
#include<ostream>
class HR{
private:
		
public:

		
};

#endif
