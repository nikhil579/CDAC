#ifndef Employee_h
#define Employee_h
#include<iostream>
#include<cstring>
#include<ostream>
class Employee{
private:
		
public:
	int id;
	char* name;
	char* city;
	int sal;
		
};

#endif
