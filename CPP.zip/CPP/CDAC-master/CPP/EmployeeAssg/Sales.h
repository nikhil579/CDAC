#ifndef Sales_h
#define Sales_h
#include<iostream>
#include<cstring>
#include<ostream>
class Sales{
private:
		
public:

		
};

#endif
