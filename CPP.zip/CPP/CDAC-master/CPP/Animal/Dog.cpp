#include"Dog.h"
using namespace std;

Dog::Dog()
{
	cout<<"Dog::Dog()"<<endl;		
}

Dog::Dog(int p):Animal(p)
{
cout<<"in dog parameter"<<endl;	
cout<<"value of p is="<<p<<endl;
}
Dog::Dog(char *x,int y):Animal(x,y)
{

	cout<<"Age of Dog="<<i;
	cout<<"Name of Dog="<<name<<endl;
	
}
Dog::~Dog()
{
	cout<<"Dog::~Dog()"<<endl;
}
void Dog::speak()
{
	cout<<"BHoooo BHoooo"<<endl;
}


