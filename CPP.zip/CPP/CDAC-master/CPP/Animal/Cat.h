#ifndef _CAT__H_
#define _CAT__H_
#include"Animal.h"
#include<iostream>
#include<ostream>
#include<cstring>
using namespace std;
class Cat:public Animal
{
	int h;
	
public:
	Cat();
	//Cat(char* x,int y);
	Cat(char* x,int y,int z);
	~Cat();
	void speak();
	friend ostream& operator<<(ostream& out,Animal* z);
	
	
	

};
#endif
