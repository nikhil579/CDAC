#include"Animal.h"
#include"Cat.h"
#include"Dog.h"
#include<iostream>
using namespace std;
int main()
{
	//Animal *ptr = new Animal();

	Animal *dog = new Dog((char*)"Boss",8*12);
	Animal *cat = new Cat((char*)"Pinky",2,7);

	cout<<dog<<endl;
	cout<<cat<<endl;
	if(*cat>*dog)
	{
cout<<".............";
		cat->speak();
	}
	else
	{
		dog->speak();
	}
	delete dog;
	delete cat;
	
 cout<<"--------------------"<<endl;
     Dog d((char*)"king",12);
     d.speak();
cout<<"--------------------"<<endl;
	Dog c(d);
	c.speak();
	
}

