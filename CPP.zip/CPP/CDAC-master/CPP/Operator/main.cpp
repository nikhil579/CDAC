#include<iostream>
#include"Oper.h"
using namespace std;
int main()
{
	Oper o1;
	Oper o2;
	cin>>o1;
	cin>>o2;


	Oper add=o1+o2;
	Oper sub=o1-o2;
	Oper mul=o1*o2;
	Oper div=o1/o2;


	cout<<add<<endl;
	cout<<sub<<endl;
	cout<<mul<<endl;
	cout<<div<<endl;
}
