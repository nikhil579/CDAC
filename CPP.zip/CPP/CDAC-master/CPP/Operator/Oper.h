#include<iostream>
#include<istream>
#include<ostream>
using namespace std;
class Oper
{
         int i;
public:
         Oper();
	 Oper(int n1);
	~Oper();
	 void operator=(const Oper &x);
	 Oper operator+(Oper& x);
	 Oper operator-(Oper& x);
	 Oper operator*(Oper& x);
	 Oper operator/(Oper& x);
	friend istream& operator>>(istream& shubh,Oper &x);
	friend ostream& operator<<(ostream& hari,Oper &x);
};
