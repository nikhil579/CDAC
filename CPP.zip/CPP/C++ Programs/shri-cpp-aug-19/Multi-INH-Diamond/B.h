
#ifndef __B__H__
#define __B__H__

#include "A.h"

class B : virtual public A
{
public:
	B();
	~B();
};

#endif

