
#include <iostream>
#include "D.h"

using namespace std;

int main(int argc, char** argv) 
{
	D d;
}


