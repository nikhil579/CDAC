
#include <iostream>
#include "B.h"
using namespace std;

B::B()
{
	cout<<"B::B()"<<endl;
}

B::~B()
{
	cout<<"B::~B()"<<endl;
}

