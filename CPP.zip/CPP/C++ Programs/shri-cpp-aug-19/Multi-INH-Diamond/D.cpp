

#include <iostream>
#include "D.h"
using namespace std;

D::D()
{
	cout<<"D::D()"<<endl;
}

D::~D()
{
	cout<<"D::~D()"<<endl;
}


