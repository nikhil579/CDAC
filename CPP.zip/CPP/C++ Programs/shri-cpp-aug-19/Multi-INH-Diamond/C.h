
#ifndef __C__H__
#define __C__H__

#include "A.h"

class C : virtual public A
{
public:
	C();
	~C();
};

#endif

