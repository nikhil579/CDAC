#include <iostream>
#include "A.h"
using namespace std;

A::A()
{
	cout<<"A::A()"<<endl;
}

A::~A()
{
	cout<<"A::~A()"<<endl;
}

void A::fun()
{
	cout<<"A::fun()"<<endl;
}

