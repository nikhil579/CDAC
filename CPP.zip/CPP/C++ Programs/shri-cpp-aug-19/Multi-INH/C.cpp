

#include <iostream>
#include "C.h"
using namespace std;

C::C()
{
	cout<<"C::C()"<<endl;
}

C::~C()
{
	cout<<"C::~C()"<<endl;
}

