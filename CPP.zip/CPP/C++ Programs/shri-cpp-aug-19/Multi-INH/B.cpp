

#include <iostream>
#include "B.h"
using namespace std;

B::B()
{
	cout<<"B::B()"<<endl;
}

B::~B()
{
	cout<<"B::~B()"<<endl;
}

void B::fun2()
{
	cout<<"B::fun2()"<<endl;
}

