
#ifndef __B__H__
#define __B__H__


class B 
{
public:
	B();
	~B();
	void fun2();	
};

#endif

