
#include <cstdio>
#include "Circle.h"

int main()
{
	//Circle c1;
	//Circle c2(10);
	Circle c3(10,4,6);

	//c1.display();
	//c2.display();			
	c3.display();	
	//printf("%f", c1.getArea());

}

