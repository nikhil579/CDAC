#ifndef __CIRCLE_H__
#define __CIRCLE_H__

#include <iostream>
#include "Shape.h"
using namespace std;

class Circle : public Shape
{
	
	public:
		
		void draw()
		{
			cout<<"Circle::Draw()"<<endl;
		}
		
};

#endif

