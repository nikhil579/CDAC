
#include <cstdio>
#include "ABC.h"

ABC::ABC()
{
	printf("ABC::ABC()\n");
	i=0;
}

ABC::ABC(int x)
{
	printf("ABC::ABC(int)\n");
	i=x;
}

ABC::~ABC()
{
	printf("ABC::~ABC()\n");
}

void ABC::display()
{
	printf("i=%d\n", i);
}

