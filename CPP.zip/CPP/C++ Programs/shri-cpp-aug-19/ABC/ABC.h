
class ABC
{
	int i;

    public:
	ABC();
	ABC(int);	
	~ABC();
	void display();	
};

