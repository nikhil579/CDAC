

#include <iostream>
#include "B.h"
using namespace std;

B::B()
{
	cout<<"B::B()"<<endl;
}

B::B(int y)
{
	j=y;
	cout<<"B::B(int)"<<endl;
}

B::~B()
{
	cout<<"B::~B()"<<endl;
}

void B::show()
{
	cout<<"B::show()"<<endl;
	cout<<"J="<<j<<endl;
}

