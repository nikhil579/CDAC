#include <iostream>
#include "Number.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) 
{
	Number a;
	Number b;
	Number c=a+b;
	
	c=a+b;
	
	
}
