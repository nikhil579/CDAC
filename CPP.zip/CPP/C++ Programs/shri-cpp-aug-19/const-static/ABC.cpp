#include "ABC.h"
#include <iostream>

int ABC::s;

ABC::~ABC()
{
	printf("ABC::~ABC()\n");
}

ABC::ABC() : c(10), r(i)
{
	printf("ABC::ABC()\n");
	this->s=10;
	this->i=0;
}


void ABC::ChangeS(int x)
{
	this->s = x;	
}

void ABC::ChangeI(int x)
{
	this->i = x;	
}
void ABC::showMe() const
{
	printf("i=%d, s=%d\n", this->i, this->s);
}

void ABC::fun()
{
	printf("From FUN... s=%d\n", s);
}

void ABC::operator=(const ABC &x) 
{
	
}

