

class ABC
{
	int i;
	static int s;

public:
	ABC();
	~ABC();
	void fun2();
	static void fun();		
};




