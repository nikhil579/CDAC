
#include "ABC.h"


int main()
{
	ABC a;
	{
		ABC b;
	}
	a.fun2();
	
	ABC::fun();

	return 0; 
}

