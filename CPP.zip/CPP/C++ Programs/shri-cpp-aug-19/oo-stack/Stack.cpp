#include "Stack.h"
#include <iostream>
#include <ostream>
using namespace std;

void operator+(int x, Stack &y)
{
	y.push(x);
}

Stack::Stack()
{
	top=-1;
}

Stack::~Stack()
{
	top=-1;
}

Stack::Stack(Stack &x)
{
	this->top = x.top;
	
	int i=0;

	while(i<=top)
	{
		this->arr[i]=x.arr[i];
		i++;
	}
}

void Stack::operator=(Stack &x)
{
	this->top = -1;

	this->top = x.top;
	int i=0;
	while(i<=top)
	{
		this->arr[i]=x.arr[i];
		i++;
	}

}

void Stack::push(int x)
{
	if(top!=STACK_SIZE-1)
	{
		++top;
		arr[top]=x;
	}
	else
		cout<<"stack overflow..."<<endl;
}

int Stack::pop()
{
	if(top!=-1)
	{
		int r=arr[top];
		--top;
		return r;
	}
	else
		cout<<"stack underflow..."<<endl;
	return -1;

}

ostream& operator<<(ostream &out, Stack &x)
{
	if(x.top!=-1)
	{
		int i=x.top;
		for(;i!=-1;i--)
			out<<x.arr[i]<<"-->";
	}
	else
		out<<"stack is empty..."<<endl;
	return out;
}

