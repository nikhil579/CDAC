#include "Stack.h"
#include <iostream>
using namespace std;

int main()
{

	Stack s1;
	s1.push(10);
	s1.push(20);
	s1.push(11);
	s1.push(91);
	s1.pop();
	cout<<s1<<endl;
	
	Stack s2=s1;
	cout<<s2<<endl;
	s2.push(100);
	s2.push(200);
	cout<<s2<<endl;

	s1=s2;
	cout<<s1<<endl;

	10+s1;
	//10.op+(s1);
	//op+(10, s1);












}


