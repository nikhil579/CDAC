
class ABC
{
	char *name;
	
	public:
		
		~ABC();
		ABC(char*);	
		void operator=(ABC x);	
		
		void showMe();
};


