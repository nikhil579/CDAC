

#include <iostream>
using namespace std;
#include "Circle.h"

Circle::Circle()
{
	cout<<"Circle::Circle()"<<endl;
}

Circle::~Circle()
{
	cout<<"Circle::~Circle()"<<endl;
}

void Circle::draw()
{
	cout<<"Circle::Draw()"<<endl;
}


