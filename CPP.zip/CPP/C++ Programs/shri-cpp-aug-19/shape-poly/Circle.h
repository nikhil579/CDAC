
#ifndef _CIRCLE__H_
#define _CIRCLE__H_

#include "Shape.h"

class Circle : public Shape
{
	
public:
	Circle();
	~Circle();
	void draw();
};

#endif

