
#ifndef _TRIANGLE__H_
#define _TRIANGLE__H_

#include "Shape.h"

class Triangle : public Shape
{
	
public:
	Triangle();
	~Triangle();
	void draw();
};

#endif


