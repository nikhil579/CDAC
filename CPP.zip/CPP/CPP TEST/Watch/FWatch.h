#ifndef _FWatch__h_
#define _FWatch__h_
#include<iostream>
#include<ostream>
#include<cstring>
#include"Watch.h"
using namespace std;


class FWatch:public Watch
{
	char *os;
public:
	FWatch(char *nn, int z,char *xm);
	~FWatch();
	void setMode(int);
	//FWatch(char *ll);
friend ostream& operator<<(ostream& out,FWatch &x);
	
	

};
#endif
