#ifndef _TWatch__h_
#define _TWatch__h_

#include<iostream>
#include"Watch.h"
using namespace std;
class TWatch:public Watch
{
	
public:
	TWatch(char *mn, int y);
	~TWatch();
	void setMode(int);
	bool operator>(TWatch &);
	//friend ostream& operator<<(ostream& out,FWatch &x);

	
};
#endif
