#ifndef _Watch__h_
#define _Watch__h_
#include<iostream>
#include<cstring>
using namespace std;

class Watch
{

protected:
		char *name;
		int cost;
		int Mode;

public:
	Watch(char *nm, int x);
	~Watch();
	virtual void setMode(int)=0;
	void playAlaram()
	{
		if(Mode==0)
			cout<<"ton....ton..ton"<<endl;
		else
			cout<<"tin....tin..tin"<<endl;
	}
	
};
#endif
