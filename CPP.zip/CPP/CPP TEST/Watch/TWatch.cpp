#include"TWatch.h"
#include"Watch.h"
#include<iostream>


TWatch::TWatch(char *mn, int y):Watch(mn,y)
{
	/*name=new char[strlen(nm)+1];
	strcpy(name,nm);
	name[strlen(nm)+1];
	cost=x;*/



}
TWatch::~TWatch()
{
	
	//delete [] name;
	cout<<"in Twatch destructor"<<endl;
}
void TWatch::setMode(int n)	
{
		Mode=n;
}
bool TWatch::operator>(TWatch &x)
{
	if(this->cost>x.cost)
		
			return true;
		
		else
			return false;

}

