#include"State.h"
State::State()
{

	
}
State::State(const char *x,int n)
{
	Lang=new char[sizeof(x)];
	strcpy(Lang,x);
	this->area=n;

}

State::~State()
{

}


ostream& operator<<(ostream& out,State &x)
{
	out<<"Lang="<<x.Lang<<endl<<"area="<<x.area;
return out;
}


int operator >(State &x,State &y)
{

	if(x.area>y.area)
	{
	return 1;
	}
	else
	return 0;
}

void State:: MyTourisumSpots()
{

	
}
