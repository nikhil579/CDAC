
#include<iostream>
using namespace std;

#ifndef _STATE__H_
#define _STATE__H_
#include<ostream>
#include<cstring>

class State
{
protected:
	char *Lang;
	int area;

public:	
	State();
	virtual ~State();
	State(const char *,int);
	virtual void  MyTourisumSpots();
	friend ostream& operator<<(ostream& out,State &x);
	int friend operator >(State &,State &);
};
#endif
