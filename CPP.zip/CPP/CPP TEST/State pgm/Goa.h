
#include<iostream>
using namespace std;
#ifndef _GOA__H_
#define _GOA__H_
#include"State.h"
class Goa:public State
{

public:	
	Goa();
	~Goa();
	Goa(const char *,int);
	void MyTourisumSpots();
	
};
#endif
