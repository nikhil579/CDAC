#ifndef _Goa__H
#define _Goa__H

#include"state.h"
class Goa:public State
{
 
 public:
       Goa();
       ~Goa();
	Goa(const char * ,int);	
	void MyTourismSpots();

};
#endif
