#include<iostream>
using namespace std;
#include"state.h"
#include<cstring>
   	State::State()
	{
	 cout<<"constructor";
	
	}
   	
   		State::State(const char *l ,int a)
   		{
   		area=a;
   		language=new char[strlen(l)+1];
   		strcpy(language,l);
   		language[strlen(l)]='\0';
   		
   		
   		}
   		void State::MyTourismSpots()
   		{
   		cout<<" In MyTourismSpots()   "<<language<<endl<<area<<endl;
   		
   		}
   		
		ostream &operator<<(ostream &out,State &x)
		{
		 out<<x.language;
		 out<<x.area;
		return out;
		
		}
		
		
		bool State::operator>(State & x)
		{
		
		 if(this->area>x.area)
		 {
		 return true;
		 
		 }
		 else
		 {
		 return false;
		 }
		 
		
		
		}
		
		
		State::~State()
	   	{
	   	cout<<"destructor";
	   	
	   	}
			
	   		
