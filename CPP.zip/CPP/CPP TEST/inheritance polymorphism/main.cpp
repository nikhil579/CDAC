#include<iostream>
using namespace std;
#include"state.h"
#include"Maharashtra.h"
#include"Goa.h"
int main()
{
  State *ptr=new State();
  State *ms=new Maharashtra("Marathi",12800);
  cout<<*ms<<endl;
  State *goa=new Goa("Kokani",800);
  goa->MyTourismSpots();
if((*ms)>(*goa))
 cout<<"Ms is greater in area as compare to Goa"<<endl; 
  delete ms;
  delete goa;
}

