#include"Oper.h"

Oper::Oper()
{
	cout<<"this is default costructor"<<endl;
	i=0;
}
Oper::Oper(int n1)
{
	cout<<"this is parameterized costructor"<<endl;
	i=n1;
}
Oper::~Oper()
{
	cout<<"this is destructor"<<endl;
	i=-1;
}
void Oper::operator=(const Oper &x)
{
    cout<<"this is assingment Oper"<<endl;
	this->i=x.i;
}
Oper Oper::operator+(Oper& x)
{
	cout<<"this is + operator"<<endl;
	Oper oper1;
	oper1.i=this->i+x.i;
	return oper1;
	
}
Oper Oper::operator-(Oper& x)
{
	cout<<"this is - operator"<<endl; 
	Oper oper2;
	oper2.i=this->i-x.i;
	return oper2;
}
Oper Oper::operator*(Oper& x)
{
	cout<<"this is * operator"<<endl;
	Oper oper3;
	oper3.i=this->i*x.i;
	return oper3;
}
Oper Oper::operator/(Oper& x)
{
	cout<<"this is / operator"<<endl;
	Oper oper4;
	oper4.i=this->i/x.i;
	return oper4;
}
istream& operator>>(istream& shubh,Oper &x)
{
	shubh>>x.i;
	return shubh;
}
ostream& operator<<(ostream& hari,Oper &x)
{
	hari<<"Extraction="<<x.i;
	return hari;
}

