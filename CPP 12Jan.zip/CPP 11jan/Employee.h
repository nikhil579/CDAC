#ifndef Employee_h
#define Employee_h
#include<iostream>
#include<cstring>
#include<ostream>
class Employee{
private:
		
public:
	int id;
	char* name;
	char* city;
	char ename[20];
	int sal;
	Employee();
	~Employee();
	Employee(int id,char* name,int sal);
	Employee(int id,char* name,char* city,int sal);
	virtual int calSal(Employee *emp);
	virtual void display();
//friend ostream& operator<<(ostream &,Employee &);
	virtual void read();
	virtual void show();

	int getEmpId()            { return id;}
	/* int getEmpName()            { return name;}
	int getSalary()             { return sal;} */
};

#endif
