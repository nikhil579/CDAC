/*CPP
Write a console application which will accept user name and password at startup if user enter admin credentials then he will be able to add+del+update Employee records.
-Employee may be a type of worker, sales manager, HR.
-Employee have salary where are worker have extra working hour with per hour pay.
-Sales manager have travelling allowance with incentive as per target after completing total target.
-Hr has home allowance, incentive per requirement and number of recruitments.
-This data entered by admin, if employee login with his credentials he can see only his details.
Use file.txt to save the data.*/
#include"Employee.h"
#include"Worker.h"
#include"Manager.h"
#include<iostream>
#include<fstream>

using namespace std;
int login();
void insert();
void displayAll();
void search();
void Add();

char ch;
Employee emp[3];
    Employee obj;
int main(){
	//login();
    fstream file;
	
	//MENU DRIVEN
	int choice;
     cout<<"CHOOSE: 1.SIMPLE PROGRAM"<<" "<<"2.OBJECT ORIENTED PROGRAM"<<"\n";
     cin>>choice;
    if(choice==1){
     cout<<"SIMPLE PROGRAM:\n"<<"1.ADD AN EMPLOYEE\n"<<"2.DISPLAY\n"<<"3.SEARCH\n"<<"4.INSERT RECORD\n";
     cout<<"CHOOSE ";
	do{
        int n,size;
        cin>>n;
     switch(n){
			case 1:
				insert();
				break;
			case 2 :
				displayAll();
				break;
			case 3:
				search();
				break;
			case 4:
				Add();
				break;
			default :
				cout<<"Invalid Choice\n";
     } 
     cout<<"Do you want to continue ? : Y or N ";
     cin>>ch; 
     }while(ch=='Y'||ch=='y');
}
else
{
    cout<<"OOPS PROGRAM: \n"<<"1.ADD AN EMPLOYEE\n"<<"2.DISPLAY\n"<<"3.SEARCH\n"<<"4.INSERT RECORD\n";
     cout<<"CHOOSE ";
	do{
        int n,size;
        cin>>n;
     switch(n){
			case 1:
            cout<<"How many Employees? ";
            cin>>size;
            Employee *e1;
            for (int i = 0; i < size; i++)
            {
               	int id;
                cout<<"ID: ";
                cin>>id;
                char nm[20];
                cout<<"NAME: ";
                cin>>emp[i].ename;
                int sal;
                cout<<"SALARY: ";
                cin>>sal;
                e1=new Employee(id,nm,sal);
                e1->display();
            }

				break;
			case 2 :
				cout<<"";
				break;
			case 3:
				
				break;
			case 4:
			
				break;
			default :
				cout<<"Invalid Choice\n";
     } 
     cout<<"Do you want to continue ? : Y or N ";
     cin>>ch; 
     }while(ch=='Y'||ch=='y');
    }
}
void insert(){
	cout<<"Enter Size: "<<"\n";
    int size;
    cin>>size;
    cout<<"Enter Details: \n";
    ofstream fout("empl.txt", ios::out);
    for (int i = 0; i < size; i++)
    {
        cout<<"ID: ";
        cin>>emp[i].id;
        fout<<"ID: "<<emp[i].id<<"\n";

        cout<<"NAME: ";
        cin>>emp[i].ename;
        fout<<"NAME: "<<emp[i].ename<<"\n";

        cout<<"SALARY: ";
        cin>>emp[i].sal;
        fout<<"SALARY: "<<emp[i].sal<<"\n";
    }
    fout.close();
}
void displayAll(){
cout<<"Display: \n";
    for (int i = 0; i < 3; i++)
    {
        cout<<"ID: "<<emp[i].id<<" ";
        cout<<"NAME: "<<emp[i].ename<<" ";
        cout<<"SALARY: "<<emp[i].sal<<"\n";
    }
    cout<<"============================\n";
}

void search(){
       cout<<"Enter ID: ";
       int num=obj.getEmpId();
     
        cout<<"ID: "<<emp[num].id<<" ";
        cout<<"NAME: "<<emp[num].ename<<" ";
        cout<<"SALARY: "<<emp[num].sal<<"\n";
    
    cout<<"============================\n";
				

}

void Add(){
 
}

int login ()
{
    string userName;
    string userPassword;
    int loginAttempt = 0;

    while (loginAttempt < 5)
    {
        cout << "NAME : ";
        cin >> userName;
        cout << "PASSWORD : ";
        cin >> userPassword;

        if (userName == "admin" && userPassword == "admin")
        {
            cout << "Welcome "<<userName<<endl;
            break;
        }
        else if(userName == "nikhil" && userPassword == "nikk"){
            displayAll();
        }
        else
        {
            cout << "Invalid login attempt. Please try again.\n" << '\n';
            loginAttempt++;
        }
    }
    if (loginAttempt == 5)
    {
            cout << "Too many login attempts! The program will now terminate.";
            return 0;
    }

    cout << "Thank you for logging in.\n";
 
}