/*CPP
Write a console application which will accept user name and password at startup if user enter admin credentials then he will be able to add+del+update Employee records.
-Employee may be a type of worker, sales manager, HR.
-Employee have salary where are worker have extra working hour with per hour pay.
-Sales manager have travelling allowance with incentive as per target after completing total target.
-Hr has home allowance, incentive per requirement and number of recruitments.
-This data entered by admin, if employee login with his credentials he can see only his details.
Use file.txt to save the data.*/
#include"Employee.h"
#include"Worker.h"
#include"Manager.h"
#include<iostream>
#include<fstream>
using namespace std;
int login();
void insert();
void displayAll();
void search();
void fileAdd();
int login ()
{
    string userName;
    string userPassword;
    int loginAttempt = 0;

    while (loginAttempt < 5)
    {
        cout << "NAME : ";
        cin >> userName;
        cout << "PASSWORD : ";
        cin >> userPassword;

        if (userName == "nikhil" && userPassword == "pass")
        {
            cout << "Welcome "<<userName<<endl;
            break;
        }
        else
        {
            cout << "Invalid login attempt. Please try again.\n" << '\n';
            loginAttempt++;
        }
    }
    if (loginAttempt == 5)
    {
            cout << "Too many login attempts! The program will now terminate.";
            return 0;
    }

    cout << "Thank you for logging in.\n";
   return 0;   
}
char ch;
int main(){
	login();
	
	cout<<"=========================================="<<endl;
	cout<<"EMPLOYEE"<<endl;
	cout<<"=========================================="<<endl;
	Employee *e1 =new Employee(1,"Nikhil","Pune",579579);
	e1->display();

	cout<<"=========================================="<<endl;
	cout<<"WORKER"<<endl;
	cout<<"=========================================="<<endl;
	Worker *w=new Worker(2,"Thor","Asgard",1111111,99,999);
	w->display();

	cout<<"=========================================="<<endl;
	cout<<"MANAGER"<<endl;
	cout<<"=========================================="<<endl;
	Manager *man =new Manager(3,"Iron Man","New York",9999999,1234,23,3456);
	man->display();
	cout<<"=========================================="<<endl;
	cout<<"SALARIES: "<<endl;
	cout<<"=========================================="<<endl;
	//e1.calSal(15000);
	//w.calSal(20000);
	//man.calSal(25000);
	int num1=e1->calSal(e1);
	cout<<num1<<endl;
	cout<<"=========================================="<<endl;
	int num2=w->calSal(w);
	cout<<num2<<endl;
	cout<<"=========================================="<<endl;
	int num3=man->calSal(man);
	cout<<num2<<endl;
	cout<<"=========================================="<<endl;
	/*//FILE HANLDINDG
	ofstream file;
	file.open("empl.txt",ios::app);
	file.write((char*)e1,sizeof(e1));
	file.close();*/
	//MENU DRIVEN
	
	do{
     int n;
 
     cout<<"ENTER CHOICE\n"<<"1.ADD AN EMPLOYEE\n"<<"2.DISPLAY\n"<<"3.SEARCH\n"<<"4.INSERT RECORD\n";
     cout<<"Make a choice: ";
     cin>>n;
 
     switch(n){
			case 1:
				insert();
				break;
			case 2 :
				displayAll();
				break;
			case 3:
				search();
				break;
			case 4:
				fileAdd();
				break;
			default :
				cout<<"Invalid Choice\n";
     }
 
     cout<<"Do you want to continue ? : ";
     cin>>ch;
 
     }while(ch=='Y'||ch=='y');
     
    return 0;
}

fstream file;
void insert(){
	Employee x;
    x.read();
    file.open("empl.txt",ios::out|ios::app);
    file.write((char*)&x,sizeof(x));
    file.close();
    cout<<"Record added sucessfully.\n";
}
void displayAll(){
	Employee x;
    file.open("empl.txt",ios::out|ios::in);
	x.show();
    file.close();
}

void search(){
//read employee id
    Employee x;
    int c;
    int isFound=0;
    cout<<"Enter employee id: ";
    cin>>c;
    file.open("empl.txt",ios::out|ios::in);
    if(!file){
        cout<<"ERROR IN OPENING FILE \n";
        return;
    }
    while(file){
        if(file.read((char*)&x,sizeof(x))){
            if(x.getEmpId()==c){
                cout<<"RECORD FOUND\n";
                x.show();
                isFound=1;
                break;
            }
        }
    }
    if(isFound==0){
        cout<<"Record not found!!!\n";
    }
    file.close();
}

void fileAdd(){
 //read employee record
    Employee    x;
    Employee newEmp;
     
    //Read record to insert
    newEmp.read();
 
    fstream fin;
    //read file in input mode
    file.open("file.txt",ios::out|ios::in);
    //open file in write mode
    fin.open("TEMP.txt",ios::out|ios::out);
 
    if(!file){
        cout<<"Error in opening file.txt file!!!\n";
        return;
    }
    if(!fin){
        cout<<"Error in opening TEMP.txt file!!!\n";
        return;
    }
    while(file){
        if(file.read((char*)&x,sizeof(x))){
            if(x.getEmpId()>newEmp.getEmpId()){
                fin.write((char*)&newEmp, sizeof(newEmp));
            }
            //no need to use else
            fin.write((char*)&x, sizeof(x));
        }
    }
 
    fin.close();
    file.close();
     
    rename("TEMP.txt","file.txt");
    remove("TEMP.txt");
    cout<<"Record inserted successfully."<<endl;
}

