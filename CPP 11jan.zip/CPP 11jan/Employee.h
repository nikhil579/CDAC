#ifndef Employee_h
#define Employee_h
#include<iostream>
#include<cstring>
#include<ostream>
class Employee{
private:
		
public:
	int id;
	char* name;
	char* city;
	char ename[20];
	int sal;
	Employee();
	~Employee();
	Employee(int id,char* name,char* city,int sal);
	virtual int calSal(Employee *emp);
	virtual void display();
//friend ostream& operator<<(ostream &,Employee &);
	virtual void read();
	virtual void show();
	//will return employee id
	int getEmpId()            { return id;}
	/*//will return employee name
	int getEmpName()            { return name;}
	//will return employee salary
	int getSalary()             { return sal;}*/	
};

#endif
